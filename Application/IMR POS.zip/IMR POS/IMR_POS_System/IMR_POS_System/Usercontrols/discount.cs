﻿using POS;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace IMR_POS_System.Usercontrols
{
    public partial class discount : UserControl
    {
        public discount()
        {
            InitializeComponent();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            // Validate input fields
            string Discountname = dname.Text.Trim();
            string Percentage = percentage.Text.Trim();
            DateTime StartDate = sdate.Value.Date;
            DateTime EndDate = edate.Value.Date;
            string Type = type.Text.Trim();

            // Check for empty fields
            if (string.IsNullOrEmpty(Discountname) || string.IsNullOrEmpty(Percentage) || string.IsNullOrEmpty(Type))
            {
                MessageBox.Show("All fields marked with * are required.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Validate percentage format (assuming it should be a numeric value)
            if (!IsValidPercentage(Percentage))
            {
                MessageBox.Show("Invalid percentage. It should be a numeric value.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Validate date range
            if (StartDate > EndDate)
            {
                MessageBox.Show("Start Date cannot be later than End Date.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Initialize database connection
            db DB = new db();

            string query = $@"INSERT INTO Discount (DiscountName, StartDate , EndDate ,DiscountPercentage ,DiscountType) 
            VALUES ('{Discountname}' ,'{StartDate:yyyy-MM-dd}' , '{EndDate:yyyy-MM-dd}' ,'{Percentage}' ,'{Type}')";

            var reader = new db().Select($"SELECT * FROM Discount WHERE DiscountName = '{Discountname}'");
            var result = reader.Read();
            if (result)
            {
                MessageBox.Show("Discount already exists.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                // Execute SQL query
                DB.Execute(query);
                MessageBox.Show("Data inserted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ClearFields();
                viewdetails();
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Method to validate percentage format (assuming it should be a numeric value)
        private bool IsValidPercentage(string percentage)
        {
            return decimal.TryParse(percentage, out _);
        }

        // Method to clear all input fields
        private void ClearFields()
        {
            dname.Text = "";
            percentage.Text = "";
            sdate.Value = DateTime.Now;
            edate.Value = DateTime.Now;
            type.Text = "";
        }

        private void viewdetails()
        {
            // Select data to datagridview and display
            var reader = new db().Select("SELECT * FROM Discount");
            dataGridView1.Rows.Clear();
            while (reader.Read())
            {
                dataGridView1.Rows.Add(reader["DiscountID"], reader["DiscountName"], reader["StartDate"], reader["EndDate"], reader["DiscountPercentage"], reader["DiscountType"]);
            }
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
           
            string rate = taxrates.Text.Trim();

            // Check for empty fields
            if (string.IsNullOrEmpty(rate))
            {
                MessageBox.Show("All fields marked with * are required.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }


            // Initialize database connection
            db DB = new db();

            string query = $@"INSERT INTO TaxRate(TaxRate) 
            VALUES ('{rate}')";


            try
            {
                // Execute SQL query
                DB.Execute(query);
                MessageBox.Show("Data inserted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ClearFields();
                viewdetail();
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void viewdetail()
        {
            // Select data to datagridview and display
            var reader = new db().Select("SELECT * FROM TaxRate");
            dataGridView2.Rows.Clear();
            while (reader.Read())
            {
                dataGridView2.Rows.Add(reader["TaxRateID"], reader["TaxRate"]);
            }
        }

        private void viewdetail3()
        {
            // Select data to datagridview and display
            var reader = new db().Select("SELECT * FROM ProductDiscount");
            dataGridView3.Rows.Clear();
            while (reader.Read())
            {
                dataGridView3.Rows.Add(reader["ProductDiscountID"], reader["ProductID"], reader["DiscountID"]);
            }
        }

        private void discount_Load(object sender, EventArgs e)
        {
            viewdetail();
            viewdetails();
            viewdetail3();
            LoadCombo();
        }

        private void LoadCombo()
        {
            try
            {
                db db = new db();

                using (SqlDataReader reader = db.Select("SELECT ProductID FROM Product"))
                {
                    DataTable dt = new DataTable();
                    dt.Load(reader);
                    PID.DisplayMember = "ProductID";
                    PID.DataSource = dt;
                }

                using (SqlDataReader reader = db.Select("SELECT DiscountID FROM Discount"))
                {
                    DataTable dt = new DataTable();
                    dt.Load(reader);
                    DID.DisplayMember = "DiscountID";
                    DID.DataSource = dt;
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to load Employee data: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            string PD = PID.Text.Trim();
            string DId = DID.Text.Trim();

            // Initialize database connection
            db DB = new db();

            string query = $@"INSERT INTO ProductDiscount (ProductID , DiscountID) 
            VALUES ('{PD}','{DId}')";
            var reader = new db().Select($"SELECT * FROM ProductDiscount WHERE ProductID = '{PD}' AND DiscountID = '{DId}'");
            var result = reader.Read();
            if (result)
            {
                MessageBox.Show("Product Discount already exists.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            try
            {
                // Execute SQL query
                DB.Execute(query);
                MessageBox.Show("Data inserted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ClearFields();
                viewdetail3();
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

    }
}
