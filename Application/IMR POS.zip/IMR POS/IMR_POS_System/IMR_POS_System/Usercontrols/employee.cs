﻿using POS;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IMR_POS_System.Usercontrols
{
    public partial class employee : UserControl
    {
        public employee()
        {
            InitializeComponent();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            // Validate input fields
            string FirstName = fname.Text.Trim();
            string LastName = lname.Text.Trim();
            string Email = emails.Text.Trim();
            string contact = tp.Text.Trim();
            string Roal = roal.Text.Trim();
            string Hiredate = hiredate.Value.ToString("yyyy-MM-dd");


            // Initialize database connection
            db DB = new db();

            string query = $@"INSERT INTO Employee (FirstName, LastName , RoleID ,Email , PhoneNumber , HireDate) 
            VALUES ('{FirstName}' , '{LastName}' , '{Roal}' ,'{Email}', '{contact}' , '{Hiredate}')";

            try
            {
                // Execute SQL query
                DB.Execute(query);
                MessageBox.Show("Data inserted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ClearFields();
                viewdetails();
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void ClearFields()
        {
            fname.Text = "";
            lname.Text = "";
            emails.Text = "";
            tp.Text = "";
            roal.Text = "";
            hiredate.Text = "";
        }

        private void LoadCombo()
        {
            try
            {
                db db = new db();

                using (SqlDataReader reader = db.Select("SELECT RoleID FROM Role"))
                {
                    DataTable dt = new DataTable();
                    dt.Load(reader);
                    roal.DisplayMember = "RoleID";
                    roal.DataSource = dt;
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to load Employee data: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void employee_Load(object sender, EventArgs e)
        {
            LoadCombo();
            viewdetails();
        }

        private void viewdetails()
        {
            // Select data to datagridview and display
            var reader = new db().Select("SELECT * FROM Employee");
            dataGridView1.Rows.Clear();
            while (reader.Read())
            {
                dataGridView1.Rows.Add(reader["EmployeeID"], reader["FirstName"], reader["LastName"], reader["RoleID"], reader["Email"], reader["PhoneNumber"], reader["HireDate"]);
            }
        }
    }
}
