﻿using POS;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace IMR_POS_System.Usercontrols
{
    public partial class customer : UserControl
    {
        public customer()
        {
            InitializeComponent();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            // Validate input fields
            string FirstName = fname.Text.Trim();
            string LastName = lname.Text.Trim();
            string Email = emails.Text.Trim();
            string contact = tp.Text.Trim();
            string addressline1 = adl1.Text.Trim();
            string addressline2 = adl2.Text.Trim();
            string city = cty.Text.Trim();
            string postalcode = pcode.Text.Trim();

            // Check for empty fields
            if (string.IsNullOrEmpty(FirstName) || string.IsNullOrEmpty(LastName) || string.IsNullOrEmpty(Email) ||
                string.IsNullOrEmpty(contact) || string.IsNullOrEmpty(addressline1) || string.IsNullOrEmpty(city) ||
                string.IsNullOrEmpty(postalcode))
            {
                MessageBox.Show("All fields marked with * are required.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Validate email format
            if (!IsValidEmail(Email))
            {
                MessageBox.Show("Invalid email address.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Validate phone number format (assuming it's numeric and has a specific length, e.g., 10 digits)
            if (!IsValidPhoneNumber(contact))
            {
                MessageBox.Show("Invalid phone number. It should be 10 digits long.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Initialize database connection
            db DB = new db();

            string query = $@"INSERT INTO Customer (FirstName, LastName , Email ,PhoneNumber ,AddressLine1 , AddressLine2 ,City , PostalCode) 
            VALUES ('{FirstName}' , '{LastName}' ,'{Email}' , '{contact}' , '{addressline1}' , '{addressline2}' ,'{city}' , '{postalcode}')";

            var reader = new db().Select($"SELECT * FROM Customer WHERE  PhoneNumber = '{contact}'");
            var result = reader.Read();
            if (result)
            {
                MessageBox.Show("Customer already exists.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                // Execute SQL query
                DB.Execute(query);
                MessageBox.Show("Data inserted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ClearFields();
                viewdetails();
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Method to validate email format
        private bool IsValidEmail(string email)
        {
            try
            {
                var addr = new System.Net.Mail.MailAddress(email);
                return addr.Address == email;
            }
            catch
            {
                return false;
            }
        }

        // Method to validate phone number format (assuming 10 digits)
        private bool IsValidPhoneNumber(string phoneNumber)
        {
            return System.Text.RegularExpressions.Regex.IsMatch(phoneNumber, @"^\d{10}$");
        }

        private void viewdetails()
        {
            // Select data to datagridview and display
            var reader = new db().Select("SELECT * FROM Customer");
            dataGridView1.Rows.Clear();
            while (reader.Read())
            {
                dataGridView1.Rows.Add(reader["CustomerID"], reader["FirstName"], reader["LastName"], reader["Email"] , reader["PhoneNumber"] , reader["AddressLine1"] , reader["AddressLine2"] , reader["City"] , reader["PostalCode"], reader["RegistrationDate"]);
            }
        }

        private void ClearFields()
        {
            fname.Text = "";
            lname.Text = "";
            emails.Text = "";
            tp.Text = "";
            adl1.Text = "";
            adl2.Text = "";
            cty.Text = "";
            pcode.Text = "";
        }

        private void customer_Load(object sender, EventArgs e)
        {
            viewdetails();
        }
    }
}
