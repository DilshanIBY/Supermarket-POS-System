﻿using POS;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IMR_POS_System.Usercontrols
{
    public partial class stock : UserControl
    {
        public stock()
        {
            InitializeComponent();
        }

        private void stock_Load(object sender, EventArgs e)
        {
            LoadCombo();
            viewdetail();
        }

        private void LoadCombo()
        {
            try
            {
                db DB = new db();

                using (SqlDataReader reader = DB.Select("SELECT ProductID FROM Product"))
                {
                    DataTable dt = new DataTable();
                    dt.Load(reader);
                    PID.DisplayMember = "ProductID";
                    PID.DataSource = dt;
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to load Employee data: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void viewdetail()
        {
            // Select data to datagridview and display
            var reader = new db().Select("SELECT * FROM Stock");
            dataGridView1.Rows.Clear();
            while (reader.Read())
            {
                dataGridView1.Rows.Add(reader["StockID"], reader["ProductID"], reader["QuantityAvailable"], reader["LastRestockedDate"]);
            }
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            string PD = PID.Text.Trim();
            int qty = Convert.ToInt32(this.qty.Text);
            string LDATE = ldate.Value.ToString("yyyy-MM-dd");

            // Initialize database connection
            db DB = new db();

            string query = $@"INSERT INTO Stock (ProductID , QuantityAvailable,LastRestockedDate) 
            VALUES ('{PD}','{qty}' , '{LDATE}')";
            
            try
            {
                // Execute SQL query
                DB.Execute(query);
                MessageBox.Show("Data inserted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ClearFields();
                viewdetail();
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            void ClearFields()
            {
                PID.Text = "";
                ldate.Value = DateTime.Now;
            }
        }
    }
}
