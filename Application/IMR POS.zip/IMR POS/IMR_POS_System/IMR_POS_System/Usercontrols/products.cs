﻿using POS;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace IMR_POS_System.Usercontrols
{
    public partial class products : UserControl
    {
        public products()
        {
            InitializeComponent();
        }

        private void products_Load(object sender, EventArgs e)
        {
            LoadCombo();
            viewdetails();
        }

        private void LoadCombo()
        {
            try
            {
                db db = new db();
                
                    using (SqlDataReader reader = db.Select("SELECT CategoryID FROM Category"))
                    {
                        DataTable dt = new DataTable();
                        dt.Load(reader);
                        CID.DisplayMember = "CategoryID";
                        CID.DataSource = dt;
                    }

                    using (SqlDataReader reader = db.Select("SELECT BrandID FROM Brand"))
                    {
                        DataTable dt = new DataTable();
                        dt.Load(reader);
                        BID.DisplayMember = "BrandID";
                        BID.DataSource = dt;
                    }
                    using (SqlDataReader reader = db.Select("SELECT TaxRateID FROM TaxRate"))
                    {
                        DataTable dt = new DataTable();
                        dt.Load(reader);
                        TID.DisplayMember = "TaxRateID";
                        TID.DataSource = dt;
                    }
                
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to load Employee data: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            // Validate input fields
            string ProductName = pname.Text.Trim();
            string CategoryID = CID.Text.Trim();
            string BrandID = BID.Text.Trim();
            string UnitPrice = uprice.Text.Trim();
            string TaxRateID = TID.Text.Trim();
            string ReorderLevel = rlevel.Text.Trim();
            string IsActive = status.Text.Trim();

            if(IsActive == "Active")
            {
                IsActive = "1";
            }
            else
            {
                IsActive = "0";
            }

            // Initialize database connection
            db DB = new db();

            string query = $@"INSERT INTO Product (ProductName, CategoryID , BrandID ,UnitPrice ,TaxRateID , ReorderLevel ,IsActive) 
            VALUES ('{ProductName}' , '{CategoryID}' ,'{BrandID}' , '{UnitPrice}' , '{TaxRateID}' , '{ReorderLevel}' ,'{IsActive}')";


            try
            {
                // Execute SQL query
                DB.Execute(query);
                MessageBox.Show("Data inserted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ClearFields();
                viewdetails();
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void viewdetails()
        {
            var reader = new db().Select("SELECT * FROM Product");
            dataGridView1.Rows.Clear();
            while (reader.Read())
            {
                dataGridView1.Rows.Add(reader["ProductID"], reader["ProductName"], reader["CategoryID"], reader["BrandID"], reader["UnitPrice"], reader["TaxRateID"], reader["ReorderLevel"], reader["IsActive"]);
            }
        }

        private void ClearFields()
        {
            pname.Text = "";
            CID.Text = "";
            BID.Text = "";
            uprice.Text = "";
            TID.Text = "";
            rlevel.Text = "";
            status.Text = "";
        }
    }
}
